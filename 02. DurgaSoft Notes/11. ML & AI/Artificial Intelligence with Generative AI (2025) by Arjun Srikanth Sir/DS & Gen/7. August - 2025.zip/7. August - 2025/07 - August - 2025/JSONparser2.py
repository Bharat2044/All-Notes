import time
import langchain
from langchain_core.output_parsers import JsonOutputParser
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from dotenv import load_dotenv

load_dotenv()


model = ChatOpenAI()
parser = JsonOutputParser()
template = PromptTemplate(
        template = "Create a JSON Character Profile for a {role} in a {genre} story,\n {format_instruction}",
        input_variables= ["role", "genre"],
        partial_variables= {"format_instruction" : parser.get_format_instructions()}
            )

chain = template | model | parser
result = chain.invoke({"role" : "detective", "genre" : "mystery"})
print(result)
print()
print("*********************************************")
for k, v in result.items():
    print(k,": ", v)
    print()
    time.sleep(1)