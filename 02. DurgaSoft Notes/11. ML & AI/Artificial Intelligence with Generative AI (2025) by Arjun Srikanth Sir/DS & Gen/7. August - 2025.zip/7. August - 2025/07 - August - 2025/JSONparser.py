import time
import langchain
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.prompts import PromptTemplate
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

load_dotenv()

model = ChatOpenAI()
parser = JsonOutputParser()

template = PromptTemplate(
                   template = "Give me 5 facts about {topic} \n {format_instruction}", 
                   input_variables= ["topic"], 
                   partial_variables={"format_instruction" : parser.get_format_instructions()}
                        )

chain = template | model | parser
result = chain.invoke({"topic" : "black hole"})
print(result)

print("****************************************************")
for key, value in result.items(): 
    print(key)
    print(value)
    print()
    time.sleep(1)
