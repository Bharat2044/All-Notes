from langchain_openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

model = OpenAI()

msg = input("Enter Prompt : ")

# result = model.invoke("What is the Capital of INDIA")

result = model.invoke(msg)

print(result)