from langchain_openai import ChatOpenAI
from dotenv import load_dotenv

load_dotenv()

model = ChatOpenAI(model="gpt-4") 

msg = input("Enter Prompt: ")

result = model.invoke(msg)

print(result.content) 