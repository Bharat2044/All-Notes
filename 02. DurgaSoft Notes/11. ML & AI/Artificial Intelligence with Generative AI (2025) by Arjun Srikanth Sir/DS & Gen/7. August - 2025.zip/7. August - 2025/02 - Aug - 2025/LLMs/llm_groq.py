import langchain
from langchain_groq import ChatGroq
from dotenv import load_dotenv

load_dotenv()

llm = ChatGroq(temperature=0, 
         model = "llama-3.3-70b-versatile"
          )
query = input("Enter The Prompt : ")

resp = llm.invoke(query)
print("------------------------------------------")
print(resp.content)
