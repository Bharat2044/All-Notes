from langchain_openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

model = OpenAI(model = "gpt-3.5-turbo-instruct")

msg = input("Enter Prompt : ")

# result = model.invoke("What is the Capital of INDIA")

result = model.invoke(msg)

print(result)