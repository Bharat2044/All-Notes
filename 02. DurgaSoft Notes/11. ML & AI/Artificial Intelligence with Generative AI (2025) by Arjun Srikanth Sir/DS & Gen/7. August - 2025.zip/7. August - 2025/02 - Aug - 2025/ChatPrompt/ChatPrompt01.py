import langchain
# from langchain.prompts import ChatPromptTemplate
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv

load_dotenv()

template = ChatPromptTemplate.from_messages([
    SystemMessage(content="You are an experienced career coach. Provide practical and friendly career advice"),
    HumanMessage(content = "I have offers from a {job1} and a {job2}. Which one should i go with based on long-term growth")
         ])

messages = template.format_messages(
                job1 = "startup",
                job2 = "corporate company"
            )

model = ChatOpenAI(model = "gpt-4")

result = model.invoke(messages)
print(result.content)