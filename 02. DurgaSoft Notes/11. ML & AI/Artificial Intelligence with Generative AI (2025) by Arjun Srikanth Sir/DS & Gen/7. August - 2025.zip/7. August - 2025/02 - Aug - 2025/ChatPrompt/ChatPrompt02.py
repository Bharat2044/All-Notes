import langchain
from langchain_core.prompts import ChatPromptTemplate, SystemMessagePromptTemplate, HumanMessagePromptTemplate
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv

load_dotenv()



template = ChatPromptTemplate.from_messages([
        SystemMessage(content="You are a coding tutor who explains programming concepts to beginners using simple language and real-world examples"),
        HumanMessage(content="Can you explain what is {topic} in {language}? Please give some beginner-friendly examples")
            ])


prompt = template.format_messages(
            topic = "forloop", 
            language = "Python"
)

model = ChatOpenAI(model = "gpt-4")

result = model.invoke(prompt)
print(result.content)
