import langchain
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate, ChatPromptTemplate, FewShotPromptTemplate
# from langchain.prompts import PromptTemplate, ChatPromptTemplate, FewShotPromptTemplate
from dotenv import load_dotenv

load_dotenv()

# Creating a Prompt Template
# PromptTemplate.from_template

prompt = PromptTemplate(  
            template = "Translate the following sentence into Hindi : {sentence}",
            input_variables=["sentence"]
                )
msg = input("Enter String : ")
input_prompt = prompt.format(sentence = msg)

print(input_prompt)

print("***************************************************")

model = ChatOpenAI(model = "gpt-4")
result = model.invoke(input_prompt)
print(result.content)