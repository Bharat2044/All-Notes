import langchain
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv

load_dotenv()

llm = ChatOpenAI(model = "gpt-4")

result = llm.invoke("Translate following sentence to hindi : \n Hi All, How are you?")

print(result.content)