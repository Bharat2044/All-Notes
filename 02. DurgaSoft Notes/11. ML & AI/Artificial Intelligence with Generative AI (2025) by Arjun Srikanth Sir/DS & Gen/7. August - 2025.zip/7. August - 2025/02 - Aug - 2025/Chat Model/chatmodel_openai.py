from langchain_openai import OpenAI, ChatOpenAI
from dotenv import load_dotenv
load_dotenv()

# model = OpenAI(model = "gpt-3.5-turbo-instruct")
chatmodel = ChatOpenAI(model = "gpt-4-turbo")

resp = chatmodel.invoke("Name planets in our Solar System")

print(resp.content)

