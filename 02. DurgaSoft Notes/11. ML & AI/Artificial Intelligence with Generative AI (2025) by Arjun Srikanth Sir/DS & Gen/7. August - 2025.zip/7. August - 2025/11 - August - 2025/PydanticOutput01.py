import langchain
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from  pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
load_dotenv()

model = ChatOpenAI()

# Pydantic Class with Instruction
class Person(BaseModel) : 
    name : str  =  Field(description = "Name of the Person")
    age : int =  Field(gt = 30 ,description= "Age of the Person")
    city : str = Field(description="Name of the City person belongs to")

# Embedding Pydantic Class into Pydantic Output Parser
parser = PydanticOutputParser(pydantic_object=Person)

#Creating Prompt Tempate
template = PromptTemplate(
                template="Generate name, age, and city of a {origin} person \n {format_instruction}",
                input_variables= ["origin"],
                partial_variables={ "format_instruction" : parser.get_format_instructions()}
                    )

chain = template | model | parser

final_result = chain.invoke({"origin" : "Japanese"})

print(final_result)

