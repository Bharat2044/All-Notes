from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from pydantic import BaseModel, Field
from typing import List
load_dotenv()

# Define the model
model = ChatOpenAI()

class Movie(BaseModel):
    title: str = Field(description="Title of the movie")
    year: int = Field(description="Release year of the movie")
    genres: List[str] = Field(description="List of movie genres")
    rating: float = Field(gt=0, lt=10, description="IMDB-like rating")

parser = PydanticOutputParser(pydantic_object=Movie)

template = PromptTemplate(
    template='Generate details for a fictional {genre} movie.\n{format_instruction}',
    input_variables=['genre'],
    partial_variables={'format_instruction': parser.get_format_instructions()}
)
chain = template | model | parser
final_result = chain.invoke({'genre': 'sci-fi thriller'})
print(final_result)
