import langchain
from langchain_openai import ChatOpenAI
from langchain_core.prompts import FewShotPromptTemplate, PromptTemplate
from dotenv import load_dotenv

load_dotenv()

examples = [
            {"text" : "I Love this movie", 
             "label" : "Postive"},
            {"text" : "This is the worst thing i've seen", 
             "label" : "Negative"},
            {"text" : "It was okay movie, we can watch once", 
             "label" : "Neutral"} 
            ]

prompt = PromptTemplate(
        template = "Review : {text}\n Sentiment : {label}",
        input_variables = ["text", "label"]
                )
few_shot_prompt = FewShotPromptTemplate( 
                    examples = examples,
                    example_prompt = prompt,
                    prefix = "Act as Sentiment Classification Assistant, Based on example please classify provided inputs", 
                    suffix = "Review : {text}\n Sentiment",
                    input_variables = ["text"] )

input_prompt = few_shot_prompt.format(text = "This product is exceeded my expectations")

# print(input_prompt)

llm = ChatOpenAI(model = "gpt-4")
result = llm.invoke(input_prompt)
print(input_prompt,end = " ")
print(result.content)