import langchain
from langchain_openai import ChatOpenAI
from langchain_core.prompts import FewShotPromptTemplate, PromptTemplate
from dotenv import load_dotenv

load_dotenv()

examples = [
            { "sentence" : "The quick brown dog jumped over white rabbit", "keywords" : "dog, rabbit"},
            {"sentence" : "Artificial Intelligence is chaing the world", "keywords" : "Artificial Intelligence, world"},
            {"sentence" : "Python is multi purpose programming language", "keywords" : "Python, programming language"}
                ]

prompt = PromptTemplate(
                template = "Sentence : {sentence}\n Keywords :{keywords}",
                input_variables=["sentence", "keywords"]
                )

few_shot_prompt = FewShotPromptTemplate(
                        examples = examples,
                        example_prompt = prompt,
                        prefix = "Extract the main keywords from the following sentence",
                        suffix = "Sentence : {sentence}\n Keywords : ",
                        input_variables = ["sentence"]
                  )

input_prompt = few_shot_prompt.format(sentence = "LangChain simplifies development of LLM powered apps" )

llm = ChatOpenAI(model = "gpt-4")

result = llm.invoke(input_prompt)

print(result.content)