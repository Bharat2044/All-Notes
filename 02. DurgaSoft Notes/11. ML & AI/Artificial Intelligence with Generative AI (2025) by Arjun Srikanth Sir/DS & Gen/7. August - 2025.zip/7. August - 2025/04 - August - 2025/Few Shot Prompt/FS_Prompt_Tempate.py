import langchain
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from dotenv import load_dotenv

load_dotenv()

examples = """ 
Q : If I have 3 apples and buy 2 more, how many do i have after eating 1 of them ?"
A : 4

Q : John has 10 ballons, he gave 4 of them to his friends, How many are left >
A : 6
"""

question = "Sara has 8 pens and lost 3 of them. How many left?"

prompt = PromptTemplate(
                        template = """ You are a helpful math assistant, 
                                    Solve the question based on the few examples provided {examples}
                                    
                                    Q : {question}
                                    A : """, 
                        input_variables= ["examples", "question"]
        )

input_prompt = prompt.format(examples = examples, question = question)
llm = ChatOpenAI()
response = llm.invoke(input_prompt)
print(response.content)