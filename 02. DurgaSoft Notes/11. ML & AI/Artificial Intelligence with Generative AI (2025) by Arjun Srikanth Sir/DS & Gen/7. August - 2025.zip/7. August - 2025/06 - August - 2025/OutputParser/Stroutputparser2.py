import langchain
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from dotenv import load_dotenv

load_dotenv()

model = ChatOpenAI()

# Prompt -1 for First Task
prompt1 = PromptTemplate(
                template = "Write a detailed report on {topic}",
                input_variables= ["topic"]
                )

# Prompt - 2 for Second Task
prompt2 = PromptTemplate(
            template = "Write a 5 lines summary on the following text. \n {text}",
            input_variables=["text"]
                 )

parser = StrOutputParser()

chain = prompt1 | model | parser | prompt2 | model | parser


result = chain.invoke({"topic" : "black hole"})

print(result)
