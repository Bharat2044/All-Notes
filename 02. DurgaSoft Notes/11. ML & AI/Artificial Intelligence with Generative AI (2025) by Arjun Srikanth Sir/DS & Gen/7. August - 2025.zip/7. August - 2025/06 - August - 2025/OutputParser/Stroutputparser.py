import langchain
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from dotenv import load_dotenv

load_dotenv()

model = ChatOpenAI()

# Prompt -1 for First Task
prompt1 = PromptTemplate(
                template = "Write a detailed report on {topic}",
                input_variables= ["topic"]
                )

# Prompt - 2 for Second Task

prompt2 = PromptTemplate(
            template = "Write a 5 lines summary on the following text. \n {text}",
            input_variables=["text"]
                 )


resp = prompt1.invoke({"topic" : "Black hole"})

result = model.invoke(resp)

resp2 = prompt2.invoke({"text" : result.content})

result2 = model.invoke(resp2)
print(result2.content)