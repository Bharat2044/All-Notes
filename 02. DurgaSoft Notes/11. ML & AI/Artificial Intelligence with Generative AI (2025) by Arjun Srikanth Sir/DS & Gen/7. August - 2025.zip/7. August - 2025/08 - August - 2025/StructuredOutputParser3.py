import langchain
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain.output_parsers import StructuredOutputParser, ResponseSchema
from dotenv import load_dotenv

load_dotenv()

model = ChatOpenAI()

schema = [
            ResponseSchema( name = "capital_city", description = "The Capital City of Country"),
            ResponseSchema( name = "population", description = "Approximate Population"),
            ResponseSchema( name = "official Language", description = "Official Languages of the Country")
        ]

parser = StructuredOutputParser.from_response_schemas(schema)

template = PromptTemplate(
                template="Give me details about Country {country}.\n {format_instruction}",
                input_variables= ["country"],
                partial_variables={"format_instruction" : parser.get_format_instructions()}
                )

chain = template | model | parser

var = input("Enter Country Name ")

result = chain.invoke({"country" : var})

print(result)