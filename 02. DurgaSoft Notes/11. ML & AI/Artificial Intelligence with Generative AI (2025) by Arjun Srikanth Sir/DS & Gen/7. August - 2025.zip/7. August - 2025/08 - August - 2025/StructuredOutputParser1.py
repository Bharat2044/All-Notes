import langchain
from  langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain.output_parsers import StructuredOutputParser, ResponseSchema
from dotenv import load_dotenv

load_dotenv()

model = ChatOpenAI()

schema = [
            ResponseSchema(name = "fact_1", description = "Fact1 about the topic"),
            ResponseSchema(name = "face_2", description = "Fact2 about the topic"),
            ResponseSchema(name = "face_3", description = "Fact3 about the topic")
            ]

parser = StructuredOutputParser.from_response_schemas(schema)

template = PromptTemplate(
            template = "Give 3 facts about {topic} \n {format_instruction}",
            input_variables= ["topic"],
            partial_variables={"format_instruction" : parser.get_format_instructions()}
                )

prompt = template.invoke({"topic" : "Indian Ocean"})

result = model.invoke(prompt)

final_result = parser.parse(result.content)

print(final_result)
